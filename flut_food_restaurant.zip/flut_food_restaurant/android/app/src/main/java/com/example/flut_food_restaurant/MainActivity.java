package com.example.flut_food_restaurant;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
