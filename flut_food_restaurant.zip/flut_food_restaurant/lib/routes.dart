// File for static routes

const String HOME = '/';
const String LOGIN = '/login';
const String SIGN_UP = '/sign-up';
