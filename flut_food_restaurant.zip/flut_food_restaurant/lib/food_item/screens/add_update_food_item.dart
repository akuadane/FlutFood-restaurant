import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flut_food_restaurant/category/bloc/category_bloc.dart';
import 'package:flut_food_restaurant/food_item/model/add_update_screen_arguments.dart';
import 'package:flut_food_restaurant/food_item/model/models.dart';
import 'package:flut_food_restaurant/ingredient/bloc/ingredient_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';

class AddUpdateFoodItem extends StatefulWidget {
  static const String routeName = 'add-update-food-item';

  @override
  _AddUpdateFoodItemState createState() => _AddUpdateFoodItemState();
}

class _AddUpdateFoodItemState extends State<AddUpdateFoodItem> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _item = {};
  final ImagePicker imagePicker = ImagePicker();
  CategoryBloc categoryBloc;
  IngredientBloc ingredientBloc;
  PickedFile pickedFile;
  File picture;
  List<bool> checkboxesCategories;
  List<bool> checkboxesIngredients;

  Future<void> _pickFile(ImageSource src) async {
    pickedFile = await imagePicker.getImage(source: src);
    setState(() {
      picture = File(pickedFile.path);
    });
  }

  @override
  Widget build(BuildContext context) {
    final AddUpdateScreenArgument args =
        ModalRoute.of(context).settings.arguments;
    categoryBloc = BlocProvider.of<CategoryBloc>(context);
    ingredientBloc = BlocProvider.of<IngredientBloc>(context);
    checkboxesCategories =
        List.filled(categoryBloc.state.categories.length, false);
    checkboxesIngredients =
        List.filled(ingredientBloc.state.ingredients.length, false);
    if (args.edit) {
      for (int i = 0; i < categoryBloc.state.categories.length; i++) {
        if (args.item.categories.contains(categoryBloc.state.categories[i])) {
          checkboxesCategories[i] = true;
        }
      }
      for (int i = 0; i < ingredientBloc.state.ingredients.length; i++) {
        if (args.item.categories
            .contains(ingredientBloc.state.ingredients[i])) {
          checkboxesIngredients[i] = true;
        }
      }
    }
    final List ingredientFixedList =
        Iterable<int>.generate(ingredientBloc.state.ingredients.length)
            .toList();
    final List categoryFixedList =
        Iterable<int>.generate(categoryBloc.state.categories.length).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(args.edit ? 'Update Item' : "Add Item"),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 10.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  initialValue: args.edit ? args.item.name : '',
                  decoration: InputDecoration(
                      hintText: 'Enter item name',
                      border: OutlineInputBorder()),
                  validator: (value) {
                    String error = value.length < 3
                        ? "Item name should be at least 3 characters long"
                        : null;
                    return error;
                  },
                  onSaved: (value) {
                    setState(() {
                      _item['name'] = value;
                    });
                  },
                ),
                SizedBox(
                  height: 10.0,
                ),
                TextFormField(
                  keyboardType: TextInputType.number,
                  initialValue: args.edit ? args.item.price : '',
                  decoration: InputDecoration(
                      hintText: 'Enter item price',
                      border: OutlineInputBorder()),
                  validator: (value) {
                    String error = double.parse(value) <= 0.0
                        ? "Price should be greater than 0"
                        : null;
                    return error;
                  },
                  onSaved: (value) {
                    _item['price'] = double.parse(value);
                  },
                ),
                SizedBox(
                  height: 10.0,
                ),
                TextFormField(
                  initialValue: args.edit ? args.item.description : '',
                  decoration: InputDecoration(
                      hintText: 'Enter item description',
                      border: OutlineInputBorder()),
                  validator: (value) {
                    String error = value.length < 5
                        ? "Description should be at least 5 characters long"
                        : null;
                    return error;
                  },
                  onSaved: (value) {
                    _item['description'] = value;
                  },
                ),
                SizedBox(
                  height: 10.0,
                ),
                Card(
                  child: Column(
                    children: [
                      Text('Select Categories'),
                      Column(
                        children: categoryFixedList
                            .map((idx) => CheckboxListTile(
                                  value: checkboxesCategories[idx],
                                  onChanged: (value) {
                                    setState(() {
                                      checkboxesCategories[idx] = value;
                                    });
                                  },
                                ))
                            .toList(),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Text('Select Ingredients'),
                      Column(
                        children: ingredientFixedList
                            .map((idx) => CheckboxListTile(
                                  value: checkboxesIngredients[idx],
                                  onChanged: (value) {
                                    setState(() {
                                      checkboxesIngredients[idx] = value;
                                    });
                                  },
                                ))
                            .toList(),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 10.0,
                ),
                args.edit
                    ? Image.network(
                        args.item.image,
                        fit: BoxFit.cover,
                      )
                    : picture != null
                        ? Image.file(
                            picture,
                            fit: BoxFit.cover,
                          )
                        : Container(
                            child: Text('Select food picture'),
                            alignment: Alignment.center,
                          ),
                SizedBox(
                  height: 10.0,
                ),
                Row(
                  children: [
                    RaisedButton(
                      onPressed: () async {
                        _pickFile(ImageSource.camera);
                      },
                      child: Row(
                        children: [
                          Icon(Icons.camera_alt),
                          Text('Take Picture'),
                        ],
                      ),
                    ),
                    RaisedButton(
                      child: Row(
                        children: [
                          Icon(Icons.upload_outlined),
                          Text('Upload Picture'),
                        ],
                      ),
                      onPressed: () {
                        _pickFile(ImageSource.gallery);
                      },
                    ),
                  ],
                ),
                ButtonBar(
                  buttonPadding:
                      EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  children: [
                    FlatButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('CANCEL')),
                    RaisedButton(
                      onPressed: () {
                        if (_formKey.currentState.validate()) {
                        } else {
                          Scaffold.of(context).showSnackBar(SnackBar(
                              content: Text("Please provide valid data")));
                        }
                      },
                      child: Text('ADD', style: TextStyle(color: Colors.white)),
                      color: Colors.deepPurple,
                    )
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    ingredientBloc?.close();
    categoryBloc?.close();
    super.dispose();
  }
}
