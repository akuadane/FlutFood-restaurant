import 'package:flutter/material.dart';
import 'package:flut_food_restaurant/app.dart';

Future<void> main() async {
  runApp(FlutFood());
}
